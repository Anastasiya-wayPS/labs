﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab21 {
				public class Flight {
								public String Code { get; set; }
								public String TransportType { get; set; }
								public String Start { get; set; }
								public String Destination { get; set; }
								public float Price { get; set; }
				}
}
